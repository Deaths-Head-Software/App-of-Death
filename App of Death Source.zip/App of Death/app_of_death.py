#!/usr/bin/env python3
"""
App of Death — Linux Package Converter
Death's Head Software

Converts between Linux package formats:
  .deb  (Debian/Ubuntu)
  .rpm  (Red Hat/Fedora/SUSE)
  .pkg.tar.zst / .pkg.tar.xz  (Arch Linux / Pacman)

Backend tools used:
  alien    — deb ↔ rpm conversion
  debtap   — deb → pacman conversion
  dpkg-deb — building .deb packages
  rpmbuild — building .rpm packages (via alien)

Run as root (or via sudo) for best results — alien and debtap
typically require root privileges.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from enum import Enum
from pathlib import Path

# --- PyQt6 Imports ---
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QSize, QProcess
)
from PyQt6.QtGui import (
    QAction, QColor, QFont, QIcon, QPainter, QPalette, QPixmap
)
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFrame,
    QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QScrollArea, QSizePolicy, QSplashScreen, QStatusBar,
    QTextEdit, QVBoxLayout, QWidget
)


# =============================================================================
# Global Definitions
# =============================================================================

APP_NAME        = "App of Death"
APP_VERSION     = "1.0.0"
ORG_NAME        = "Death's Head Software"
WINDOW_WIDTH    = 900
WINDOW_HEIGHT   = 700

# Colours
CLR_BG          = "#141414"
CLR_BG_LIGHT    = "#1e1e1e"
CLR_BG_INPUT    = "#252525"
CLR_BORDER      = "#3a3a3a"
CLR_RED         = "#8b0000"
CLR_RED_HOVER   = "#a00000"
CLR_RED_PRESSED = "#6b0000"
CLR_TEXT        = "#e0e0e0"
CLR_TEXT_DIM    = "#888888"
CLR_WHITE       = "#ffffff"
CLR_GREEN       = "#2e7d32"
CLR_YELLOW      = "#b8860b"
CLR_ERROR       = "#cc3333"


# =============================================================================
# Package Format Enum
# =============================================================================

class PkgFormat(Enum):
    DEB    = "deb"
    RPM    = "rpm"
    PACMAN = "pacman"

    @property
    def label(self) -> str:
        labels = {
            PkgFormat.DEB:    ".deb  (Debian / Ubuntu)",
            PkgFormat.RPM:    ".rpm  (Red Hat / Fedora / SUSE)",
            PkgFormat.PACMAN: ".pkg.tar.*  (Arch / Pacman)",
        }
        return labels[self]

    @property
    def short(self) -> str:
        shorts = {
            PkgFormat.DEB:    "DEB",
            PkgFormat.RPM:    "RPM",
            PkgFormat.PACMAN: "Pacman",
        }
        return shorts[self]


# =============================================================================
# Utility: detect source package format from filename
# =============================================================================

def detect_format(filepath: str) -> PkgFormat | None:
    """Detect package format from file extension."""
    name = Path(filepath).name.lower()
    if name.endswith(".deb"):
        return PkgFormat.DEB
    elif name.endswith(".rpm"):
        return PkgFormat.RPM
    elif (name.endswith(".pkg.tar.zst") or name.endswith(".pkg.tar.xz")
          or name.endswith(".pkg.tar.gz") or name.endswith(".pkg.tar.bz2")
          or name.endswith(".pkg.tar")):
        return PkgFormat.PACMAN
    return None


def tool_available(name: str) -> bool:
    """Check whether a CLI tool is on PATH."""
    return shutil.which(name) is not None


# =============================================================================
# Conversion Worker (runs in a QThread)
# =============================================================================

class ConvertWorker(QThread):
    """Performs the actual package conversion in a background thread."""

    log_message  = pyqtSignal(str)        # plain log line
    log_error    = pyqtSignal(str)        # error line (shown in red)
    log_success  = pyqtSignal(str)        # success line (shown in green)
    progress     = pyqtSignal(int)        # 0‑100
    finished_ok  = pyqtSignal(str)        # emitted with output path on success
    finished_err = pyqtSignal(str)        # emitted with error message on failure

    def __init__(
        self,
        source_path: str,
        source_fmt: PkgFormat,
        target_fmt: PkgFormat,
        output_dir: str,
        convert_scripts: bool = True,
    ):
        super().__init__()
        self.source_path     = source_path
        self.source_fmt      = source_fmt
        self.target_fmt      = target_fmt
        self.output_dir      = output_dir
        self.convert_scripts = convert_scripts

    # -----------------------------------------------------------------
    def run(self):
        try:
            self._do_convert()
        except Exception as exc:
            self.finished_err.emit(str(exc))

    # -----------------------------------------------------------------
    def _exec(self, cmd: list[str], cwd: str | None = None) -> tuple[int, str, str]:
        """Run a subprocess, streaming output back to the log."""
        self.log_message.emit(f"▸ {' '.join(cmd)}")
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd,
            text=True,
        )
        stdout, stderr = proc.communicate()
        if stdout.strip():
            for line in stdout.strip().splitlines():
                self.log_message.emit(f"  {line}")
        if stderr.strip():
            for line in stderr.strip().splitlines():
                self.log_message.emit(f"  [stderr] {line}")
        return proc.returncode, stdout, stderr

    # -----------------------------------------------------------------
    def _do_convert(self):
        src = self.source_path
        src_fmt = self.source_fmt
        tgt_fmt = self.target_fmt

        self.log_message.emit(f"Source : {src}")
        self.log_message.emit(f"From   : {src_fmt.short}")
        self.log_message.emit(f"To     : {tgt_fmt.short}")
        self.log_message.emit(f"Output : {self.output_dir}")
        self.log_message.emit("─" * 60)
        self.progress.emit(10)

        # --- Routing table ---
        if src_fmt == tgt_fmt:
            self.finished_err.emit("Source and target formats are the same.")
            return

        if src_fmt == PkgFormat.DEB and tgt_fmt == PkgFormat.RPM:
            self._deb_to_rpm(src)
        elif src_fmt == PkgFormat.RPM and tgt_fmt == PkgFormat.DEB:
            self._rpm_to_deb(src)
        elif src_fmt == PkgFormat.DEB and tgt_fmt == PkgFormat.PACMAN:
            self._deb_to_pacman(src)
        elif src_fmt == PkgFormat.RPM and tgt_fmt == PkgFormat.PACMAN:
            self._rpm_to_pacman(src)
        elif src_fmt == PkgFormat.PACMAN and tgt_fmt == PkgFormat.DEB:
            self._pacman_to_deb(src)
        elif src_fmt == PkgFormat.PACMAN and tgt_fmt == PkgFormat.RPM:
            self._pacman_to_rpm(src)
        else:
            self.finished_err.emit("Unsupported conversion route.")

    # ── alien helpers ────────────────────────────────────────────────
    def _run_alien(self, src: str, to_flag: str, expected_ext: str) -> str | None:
        """Use alien to convert a package.  Returns the output path or None."""
        if not tool_available("alien"):
            self.finished_err.emit(
                "'alien' is not installed.\n"
                "Install it with:  sudo apt install alien  (Debian/Ubuntu)\n"
                "                  sudo dnf install alien  (Fedora)"
            )
            return None

        cmd = ["alien", to_flag, "--verbose"]
        if self.convert_scripts:
            cmd.append("--scripts")
        cmd.append(src)

        self.progress.emit(30)
        rc, stdout, stderr = self._exec(cmd, cwd=self.output_dir)
        self.progress.emit(70)

        if rc != 0:
            self.finished_err.emit(f"alien exited with code {rc}.")
            return None

        # alien prints the generated filename
        generated = self._find_generated(self.output_dir, expected_ext, stdout)
        return generated

    def _find_generated(self, directory: str, ext: str, stdout: str) -> str | None:
        """Try to find the file alien / debtap created."""
        # First, try to parse it from stdout
        for line in stdout.splitlines():
            line = line.strip()
            if line.endswith(ext) or f".pkg.tar." in line:
                candidate = Path(directory) / Path(line.split()[-1]).name
                if candidate.exists():
                    return str(candidate)

        # Fallback: look for newest matching file in the directory
        matches = []
        for f in Path(directory).iterdir():
            if f.name.endswith(ext) or (ext == ".pkg.tar" and ".pkg.tar." in f.name):
                matches.append(f)
        if matches:
            matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            return str(matches[0])

        return None

    # ── Conversion routes ────────────────────────────────────────────

    def _deb_to_rpm(self, src: str):
        self.log_message.emit("Converting DEB → RPM via alien …")
        result = self._run_alien(src, "--to-rpm", ".rpm")
        if result:
            final = self._move_to_output(result)
            self.progress.emit(100)
            self.log_success.emit(f"Created: {Path(final).name}")
            self.finished_ok.emit(final)

    def _rpm_to_deb(self, src: str):
        self.log_message.emit("Converting RPM → DEB via alien …")
        result = self._run_alien(src, "--to-deb", ".deb")
        if result:
            final = self._move_to_output(result)
            self.progress.emit(100)
            self.log_success.emit(f"Created: {Path(final).name}")
            self.finished_ok.emit(final)

    def _deb_to_pacman(self, src: str):
        """Convert .deb → .pkg.tar.zst using debtap."""
        if not tool_available("debtap"):
            # Fallback: manual conversion
            self.log_message.emit("'debtap' not found — attempting manual conversion …")
            self._deb_to_pacman_manual(src)
            return

        self.log_message.emit("Converting DEB → Pacman via debtap …")
        self.progress.emit(20)

        # debtap works in the directory containing the source file
        work_dir = self.output_dir
        src_copy = str(Path(work_dir) / Path(src).name)
        if not Path(src_copy).exists():
            shutil.copy2(src, src_copy)

        cmd = ["debtap", "-Q", src_copy]
        rc, stdout, stderr = self._exec(cmd, cwd=work_dir)
        self.progress.emit(70)

        if rc != 0:
            self.log_error.emit("debtap failed — falling back to manual conversion.")
            self._deb_to_pacman_manual(src)
            return

        result = self._find_generated(work_dir, ".pkg.tar", stdout)
        if result:
            final = self._move_to_output(result)
            self.progress.emit(100)
            self.log_success.emit(f"Created: {Path(final).name}")
            self.finished_ok.emit(final)
        else:
            self.log_error.emit("debtap didn't produce output — falling back to manual.")
            self._deb_to_pacman_manual(src)

    def _deb_to_pacman_manual(self, src: str):
        """Manual deb → pacman: extract deb, build .pkg.tar.zst."""
        self.log_message.emit("Manual DEB → Pacman conversion …")
        self.progress.emit(30)

        with tempfile.TemporaryDirectory(prefix="aod_") as tmpdir:
            # Extract .deb (it's an ar archive)
            data_dir = Path(tmpdir) / "data"
            data_dir.mkdir()

            rc, _, _ = self._exec(["ar", "x", src], cwd=tmpdir)
            if rc != 0:
                self.finished_err.emit("Failed to extract .deb archive with 'ar'.")
                return

            # Find and extract data tarball
            data_tar = None
            for f in Path(tmpdir).iterdir():
                if f.name.startswith("data.tar"):
                    data_tar = f
                    break
            if not data_tar:
                self.finished_err.emit("No data.tar.* found inside .deb.")
                return

            rc, _, _ = self._exec(
                ["tar", "xf", str(data_tar), "-C", str(data_dir)],
                cwd=tmpdir
            )
            if rc != 0:
                self.finished_err.emit("Failed to extract data tarball.")
                return

            self.progress.emit(50)

            # Extract control info for metadata
            ctrl_tar = None
            for f in Path(tmpdir).iterdir():
                if f.name.startswith("control.tar"):
                    ctrl_tar = f
                    break

            pkg_name = Path(src).stem.split("_")[0]
            pkg_ver  = "1.0.0-1"
            pkg_arch = "x86_64"
            pkg_desc = "Converted from .deb by App of Death"

            if ctrl_tar:
                ctrl_dir = Path(tmpdir) / "control"
                ctrl_dir.mkdir()
                self._exec(["tar", "xf", str(ctrl_tar), "-C", str(ctrl_dir)], cwd=tmpdir)
                control_file = ctrl_dir / "control"
                if control_file.exists():
                    text = control_file.read_text(errors="replace")
                    m = re.search(r"^Package:\s*(.+)$", text, re.M)
                    if m: pkg_name = m.group(1).strip()
                    m = re.search(r"^Version:\s*(.+)$", text, re.M)
                    if m: pkg_ver = m.group(1).strip() + "-1"
                    m = re.search(r"^Architecture:\s*(.+)$", text, re.M)
                    if m:
                        a = m.group(1).strip()
                        if a in ("amd64", "x86_64"):   pkg_arch = "x86_64"
                        elif a in ("i386", "i686"):     pkg_arch = "i686"
                        elif a in ("arm64", "aarch64"): pkg_arch = "aarch64"
                        elif a == "all":                pkg_arch = "any"
                    m = re.search(r"^Description:\s*(.+)$", text, re.M)
                    if m: pkg_desc = m.group(1).strip()

            # Create .PKGINFO
            pkginfo = (
                f"pkgname = {pkg_name}\n"
                f"pkgver = {pkg_ver}\n"
                f"pkgdesc = {pkg_desc}\n"
                f"url = \n"
                f"builddate = {int(time.time())}\n"
                f"packager = App of Death <death@deathshead.software>\n"
                f"size = 0\n"
                f"arch = {pkg_arch}\n"
            )
            (data_dir / ".PKGINFO").write_text(pkginfo)

            # Create .MTREE placeholder
            (data_dir / ".MTREE").write_text("")

            self.progress.emit(70)

            # Build the .pkg.tar.zst
            out_name = f"{pkg_name}-{pkg_ver}-{pkg_arch}.pkg.tar.zst"
            out_path = str(Path(self.output_dir) / out_name)

            # Collect all files relative to data_dir
            files = []
            for root, dirs, fnames in os.walk(data_dir):
                for fn in fnames:
                    full = Path(root) / fn
                    files.append(str(full.relative_to(data_dir)))

            rc, _, _ = self._exec(
                ["tar", "--zstd", "-cf", out_path, "-C", str(data_dir)] + [".PKGINFO", ".MTREE"] +
                [f for f in files if f not in (".PKGINFO", ".MTREE")],
                cwd=str(data_dir)
            )

            self.progress.emit(90)

            if rc != 0 or not Path(out_path).exists():
                # Try without --zstd (older tar)
                out_name_xz = out_name.replace(".pkg.tar.zst", ".pkg.tar.xz")
                out_path = str(Path(self.output_dir) / out_name_xz)
                rc, _, _ = self._exec(
                    ["tar", "-cJf", out_path, "-C", str(data_dir)] + [".PKGINFO", ".MTREE"] +
                    [f for f in files if f not in (".PKGINFO", ".MTREE")],
                    cwd=str(data_dir)
                )
                if rc != 0:
                    self.finished_err.emit("Failed to create .pkg.tar archive.")
                    return

            self.progress.emit(100)
            self.log_success.emit(f"Created: {Path(out_path).name}")
            self.finished_ok.emit(out_path)

    def _rpm_to_pacman(self, src: str):
        """RPM → Pacman: go through deb as intermediate."""
        self.log_message.emit("Converting RPM → Pacman (via intermediate DEB) …")

        with tempfile.TemporaryDirectory(prefix="aod_") as tmpdir:
            # Step 1: RPM → DEB
            self.progress.emit(10)
            if not tool_available("alien"):
                self.log_message.emit("'alien' not found — attempting manual RPM extraction …")
                self._rpm_to_pacman_manual(src)
                return

            cmd = ["alien", "--to-deb", "--verbose"]
            if self.convert_scripts:
                cmd.append("--scripts")
            cmd.append(src)
            rc, stdout, _ = self._exec(cmd, cwd=tmpdir)
            self.progress.emit(40)

            if rc != 0:
                self.finished_err.emit("alien (RPM→DEB) failed.")
                return

            deb_file = self._find_generated(tmpdir, ".deb", stdout)
            if not deb_file:
                self.finished_err.emit("alien did not produce a .deb file.")
                return

            # Step 2: DEB → Pacman
            self._deb_to_pacman(deb_file)

    def _rpm_to_pacman_manual(self, src: str):
        """Manual RPM → Pacman via rpm2cpio extraction."""
        self.log_message.emit("Manual RPM → Pacman conversion …")

        if not tool_available("rpm2cpio"):
            self.finished_err.emit(
                "Neither 'alien' nor 'rpm2cpio' is installed.\n"
                "Install with:  sudo apt install rpm2cpio  or  sudo dnf install rpm"
            )
            return

        with tempfile.TemporaryDirectory(prefix="aod_") as tmpdir:
            data_dir = Path(tmpdir) / "data"
            data_dir.mkdir()

            # Extract rpm via rpm2cpio | cpio
            self.progress.emit(20)
            proc = subprocess.Popen(
                f"rpm2cpio '{src}' | cpio -idmv",
                shell=True, cwd=str(data_dir),
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            stdout, stderr = proc.communicate()
            self.progress.emit(40)

            if proc.returncode != 0:
                self.finished_err.emit("rpm2cpio extraction failed.")
                return

            # Try to get package name/version from RPM headers
            pkg_name = Path(src).stem.split("-")[0] if "-" in Path(src).stem else Path(src).stem
            pkg_ver = "1.0.0-1"
            pkg_arch = "x86_64"
            pkg_desc = "Converted from .rpm by App of Death"

            if tool_available("rpm"):
                rc2, qout, _ = self._exec([
                    "rpm", "-qp", "--queryformat",
                    "%{NAME}\\n%{VERSION}-%{RELEASE}\\n%{ARCH}\\n%{SUMMARY}",
                    src
                ])
                if rc2 == 0:
                    parts = qout.strip().splitlines()
                    if len(parts) >= 1: pkg_name = parts[0]
                    if len(parts) >= 2: pkg_ver  = parts[1]
                    if len(parts) >= 3:
                        a = parts[2]
                        if a in ("x86_64",): pkg_arch = "x86_64"
                        elif a in ("i386", "i686"): pkg_arch = "i686"
                        elif a in ("aarch64",): pkg_arch = "aarch64"
                        elif a == "noarch": pkg_arch = "any"
                    if len(parts) >= 4: pkg_desc = parts[3]

            # Build .PKGINFO
            pkginfo = (
                f"pkgname = {pkg_name}\n"
                f"pkgver = {pkg_ver}\n"
                f"pkgdesc = {pkg_desc}\n"
                f"url = \n"
                f"builddate = {int(time.time())}\n"
                f"packager = App of Death <death@deathshead.software>\n"
                f"size = 0\n"
                f"arch = {pkg_arch}\n"
            )
            (data_dir / ".PKGINFO").write_text(pkginfo)
            (data_dir / ".MTREE").write_text("")

            self.progress.emit(60)

            out_name = f"{pkg_name}-{pkg_ver}-{pkg_arch}.pkg.tar.zst"
            out_path = str(Path(self.output_dir) / out_name)

            files = []
            for root, dirs, fnames in os.walk(data_dir):
                for fn in fnames:
                    full = Path(root) / fn
                    files.append(str(full.relative_to(data_dir)))

            rc, _, _ = self._exec(
                ["tar", "--zstd", "-cf", out_path, "-C", str(data_dir)] +
                [".PKGINFO", ".MTREE"] +
                [f for f in files if f not in (".PKGINFO", ".MTREE")],
                cwd=str(data_dir)
            )

            if rc != 0 or not Path(out_path).exists():
                out_name = out_name.replace(".pkg.tar.zst", ".pkg.tar.xz")
                out_path = str(Path(self.output_dir) / out_name)
                rc, _, _ = self._exec(
                    ["tar", "-cJf", out_path, "-C", str(data_dir)] +
                    [".PKGINFO", ".MTREE"] +
                    [f for f in files if f not in (".PKGINFO", ".MTREE")],
                    cwd=str(data_dir)
                )
                if rc != 0:
                    self.finished_err.emit("Failed to create .pkg.tar archive.")
                    return

            self.progress.emit(100)
            self.log_success.emit(f"Created: {Path(out_path).name}")
            self.finished_ok.emit(out_path)

    def _pacman_to_deb(self, src: str):
        """Pacman → DEB: extract .pkg.tar.*, build .deb with dpkg-deb."""
        self.log_message.emit("Converting Pacman → DEB …")

        if not tool_available("dpkg-deb"):
            self.finished_err.emit(
                "'dpkg-deb' is not installed.\n"
                "Install with:  sudo apt install dpkg  (Debian/Ubuntu)\n"
                "               sudo pacman -S dpkg    (Arch)"
            )
            return

        with tempfile.TemporaryDirectory(prefix="aod_") as tmpdir:
            pkg_root = Path(tmpdir) / "pkg"
            pkg_root.mkdir()

            # Extract the pacman package
            self.progress.emit(15)
            rc, _, _ = self._exec(["tar", "xf", src, "-C", str(pkg_root)])
            if rc != 0:
                self.finished_err.emit("Failed to extract .pkg.tar.* archive.")
                return

            self.progress.emit(35)

            # Read .PKGINFO for metadata
            pkginfo_path = pkg_root / ".PKGINFO"
            pkg_name = "unknown"
            pkg_ver  = "1.0.0"
            pkg_arch = "amd64"
            pkg_desc = "Converted from Pacman package by App of Death"
            pkg_deps: list[str] = []

            if pkginfo_path.exists():
                text = pkginfo_path.read_text(errors="replace")
                for line in text.splitlines():
                    line = line.strip()
                    if line.startswith("#"):
                        continue
                    if "=" in line:
                        key, val = line.split("=", 1)
                        key = key.strip()
                        val = val.strip()
                        if key == "pkgname":  pkg_name = val
                        elif key == "pkgver": pkg_ver  = val
                        elif key == "pkgdesc": pkg_desc = val
                        elif key == "arch":
                            if val == "x86_64":       pkg_arch = "amd64"
                            elif val in ("i686",):    pkg_arch = "i386"
                            elif val == "aarch64":    pkg_arch = "arm64"
                            elif val == "any":        pkg_arch = "all"
                        elif key == "depend":
                            pkg_deps.append(val)

            # Remove pacman-specific metadata files from the extracted tree
            for meta in (".PKGINFO", ".MTREE", ".BUILDINFO", ".INSTALL", ".CHANGELOG"):
                p = pkg_root / meta
                if p.exists():
                    p.unlink()

            self.progress.emit(50)

            # Create DEBIAN/control
            debian_dir = pkg_root / "DEBIAN"
            debian_dir.mkdir(exist_ok=True)

            # Clean version for deb (remove epoch, ensure deb-compatible)
            deb_version = pkg_ver.replace("-", ".")
            if ":" in deb_version:
                deb_version = deb_version.split(":", 1)[1]

            control = (
                f"Package: {pkg_name}\n"
                f"Version: {deb_version}\n"
                f"Architecture: {pkg_arch}\n"
                f"Maintainer: App of Death <death@deathshead.software>\n"
                f"Description: {pkg_desc}\n"
                f"Section: misc\n"
                f"Priority: optional\n"
            )
            if pkg_deps:
                control += f"Depends: {', '.join(pkg_deps)}\n"

            (debian_dir / "control").write_text(control)

            self.progress.emit(65)

            # Build .deb
            out_name = f"{pkg_name}_{deb_version}_{pkg_arch}.deb"
            out_path = str(Path(self.output_dir) / out_name)

            rc, _, _ = self._exec(["dpkg-deb", "--build", str(pkg_root), out_path])
            self.progress.emit(90)

            if rc != 0 or not Path(out_path).exists():
                self.finished_err.emit("dpkg-deb failed to build .deb.")
                return

            self.progress.emit(100)
            self.log_success.emit(f"Created: {Path(out_path).name}")
            self.finished_ok.emit(out_path)

    def _pacman_to_rpm(self, src: str):
        """Pacman → RPM: convert via intermediate .deb, then alien to RPM."""
        self.log_message.emit("Converting Pacman → RPM (via intermediate DEB) …")

        with tempfile.TemporaryDirectory(prefix="aod_") as tmpdir:
            # Step 1: Pacman → DEB
            pkg_root = Path(tmpdir) / "pkg"
            pkg_root.mkdir()

            self.progress.emit(10)
            rc, _, _ = self._exec(["tar", "xf", src, "-C", str(pkg_root)])
            if rc != 0:
                self.finished_err.emit("Failed to extract .pkg.tar.* archive.")
                return

            # Read metadata
            pkginfo_path = pkg_root / ".PKGINFO"
            pkg_name = "unknown"
            pkg_ver  = "1.0.0"
            pkg_arch = "amd64"
            pkg_desc = "Converted from Pacman package by App of Death"

            if pkginfo_path.exists():
                text = pkginfo_path.read_text(errors="replace")
                for line in text.splitlines():
                    line = line.strip()
                    if line.startswith("#"):
                        continue
                    if "=" in line:
                        key, val = line.split("=", 1)
                        key = key.strip()
                        val = val.strip()
                        if key == "pkgname":  pkg_name = val
                        elif key == "pkgver": pkg_ver  = val
                        elif key == "pkgdesc": pkg_desc = val
                        elif key == "arch":
                            if val == "x86_64":    pkg_arch = "amd64"
                            elif val in ("i686",): pkg_arch = "i386"
                            elif val == "aarch64":  pkg_arch = "arm64"
                            elif val == "any":      pkg_arch = "all"

            for meta in (".PKGINFO", ".MTREE", ".BUILDINFO", ".INSTALL", ".CHANGELOG"):
                p = pkg_root / meta
                if p.exists():
                    p.unlink()

            debian_dir = pkg_root / "DEBIAN"
            debian_dir.mkdir(exist_ok=True)
            deb_version = pkg_ver.replace("-", ".")
            if ":" in deb_version:
                deb_version = deb_version.split(":", 1)[1]

            control = (
                f"Package: {pkg_name}\n"
                f"Version: {deb_version}\n"
                f"Architecture: {pkg_arch}\n"
                f"Maintainer: App of Death <death@deathshead.software>\n"
                f"Description: {pkg_desc}\n"
                f"Section: misc\n"
                f"Priority: optional\n"
            )
            (debian_dir / "control").write_text(control)

            deb_name = f"{pkg_name}_{deb_version}_{pkg_arch}.deb"
            deb_path = str(Path(tmpdir) / deb_name)

            if not tool_available("dpkg-deb"):
                self.finished_err.emit("'dpkg-deb' is required for Pacman → RPM conversion.")
                return

            self.progress.emit(30)
            rc, _, _ = self._exec(["dpkg-deb", "--build", str(pkg_root), deb_path])
            if rc != 0:
                self.finished_err.emit("Failed to build intermediate .deb.")
                return

            # Step 2: DEB → RPM via alien
            self.progress.emit(50)
            if not tool_available("alien"):
                self.finished_err.emit(
                    "'alien' is required for the RPM conversion step.\n"
                    "Install with:  sudo apt install alien"
                )
                return

            cmd = ["alien", "--to-rpm", "--verbose"]
            if self.convert_scripts:
                cmd.append("--scripts")
            cmd.append(deb_path)
            rc, stdout, _ = self._exec(cmd, cwd=self.output_dir)
            self.progress.emit(80)

            if rc != 0:
                self.finished_err.emit("alien (DEB→RPM) failed.")
                return

            result = self._find_generated(self.output_dir, ".rpm", stdout)
            if result:
                final = self._move_to_output(result)
                self.progress.emit(100)
                self.log_success.emit(f"Created: {Path(final).name}")
                self.finished_ok.emit(final)
            else:
                self.finished_err.emit("alien did not produce an .rpm file.")

    # ── helpers ──────────────────────────────────────────────────────

    def _move_to_output(self, path: str) -> str:
        """Move a generated file to the output directory if it's not there already."""
        p = Path(path)
        dest = Path(self.output_dir) / p.name
        if p == dest:
            return str(dest)
        if dest.exists():
            dest.unlink()
        shutil.move(str(p), str(dest))
        return str(dest)


# =============================================================================
# Splash Screen (matches Death's Head aesthetic)
# =============================================================================

def create_splash() -> QSplashScreen | None:
    """Create the App of Death splash screen."""
    try:
        splash_path = Path(__file__).parent / "splash.png"

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(
                    800, 600,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(
                text_rect,
                Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                APP_NAME,
            )
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 100)
            footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(
                footer_rect,
                Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                ORG_NAME,
            )
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(
                text_rect,
                Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                APP_NAME,
            )
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)

            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 50)
            footer_rect.setBottom(pixmap.height())
            painter.drawText(
                footer_rect,
                Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                ORG_NAME,
            )
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# =============================================================================
# Stylesheet
# =============================================================================

STYLESHEET = f"""
QMainWindow, QWidget {{
    background-color: {CLR_BG};
    color: {CLR_TEXT};
    font-family: "Courier", "Courier New", monospace;
}}

QLabel {{
    color: {CLR_TEXT};
    font-family: "Courier", "Courier New", monospace;
}}

QLabel#title {{
    color: {CLR_WHITE};
    font-size: 22px;
    font-weight: bold;
}}

QLabel#subtitle {{
    color: {CLR_TEXT_DIM};
    font-size: 11px;
}}

QLabel#section {{
    color: {CLR_RED};
    font-size: 14px;
    font-weight: bold;
    padding-top: 4px;
}}

QLineEdit {{
    background-color: {CLR_BG_INPUT};
    color: {CLR_TEXT};
    border: 1px solid {CLR_BORDER};
    border-radius: 4px;
    padding: 6px 8px;
    font-family: "Courier", "Courier New", monospace;
    font-size: 12px;
    selection-background-color: {CLR_RED};
}}

QLineEdit:focus {{
    border: 1px solid {CLR_RED};
}}

QComboBox {{
    background-color: {CLR_BG_INPUT};
    color: {CLR_TEXT};
    border: 1px solid {CLR_BORDER};
    border-radius: 4px;
    padding: 6px 8px;
    font-family: "Courier", "Courier New", monospace;
    font-size: 12px;
    min-width: 200px;
}}

QComboBox:focus {{
    border: 1px solid {CLR_RED};
}}

QComboBox::drop-down {{
    border: none;
    width: 24px;
}}

QComboBox::down-arrow {{
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid {CLR_TEXT_DIM};
    margin-right: 8px;
}}

QComboBox QAbstractItemView {{
    background-color: {CLR_BG_INPUT};
    color: {CLR_TEXT};
    border: 1px solid {CLR_BORDER};
    selection-background-color: {CLR_RED};
    selection-color: {CLR_WHITE};
    outline: none;
}}

QPushButton {{
    background-color: {CLR_RED};
    color: {CLR_WHITE};
    border: none;
    border-radius: 4px;
    padding: 8px 20px;
    font-family: "Courier", "Courier New", monospace;
    font-size: 13px;
    font-weight: bold;
}}

QPushButton:hover {{
    background-color: {CLR_RED_HOVER};
}}

QPushButton:pressed {{
    background-color: {CLR_RED_PRESSED};
}}

QPushButton:disabled {{
    background-color: {CLR_BORDER};
    color: {CLR_TEXT_DIM};
}}

QPushButton#browse {{
    min-width: 80px;
    padding: 6px 12px;
}}

QPushButton#clear {{
    background-color: {CLR_BG_INPUT};
    border: 1px solid {CLR_BORDER};
    color: {CLR_TEXT_DIM};
    font-size: 11px;
    padding: 6px 12px;
}}

QPushButton#clear:hover {{
    border: 1px solid {CLR_RED};
    color: {CLR_TEXT};
}}

QTextEdit {{
    background-color: {CLR_BG_INPUT};
    color: {CLR_TEXT};
    border: 1px solid {CLR_BORDER};
    border-radius: 4px;
    padding: 8px;
    font-family: "Courier", "Courier New", monospace;
    font-size: 11px;
    selection-background-color: {CLR_RED};
}}

QProgressBar {{
    background-color: {CLR_BG_INPUT};
    border: 1px solid {CLR_BORDER};
    border-radius: 4px;
    text-align: center;
    color: {CLR_TEXT};
    font-family: "Courier", "Courier New", monospace;
    font-size: 11px;
    height: 22px;
}}

QProgressBar::chunk {{
    background-color: {CLR_RED};
    border-radius: 3px;
}}

QCheckBox {{
    color: {CLR_TEXT};
    font-family: "Courier", "Courier New", monospace;
    font-size: 12px;
    spacing: 8px;
}}

QCheckBox::indicator {{
    width: 16px;
    height: 16px;
    border: 1px solid {CLR_BORDER};
    border-radius: 3px;
    background-color: {CLR_BG_INPUT};
}}

QCheckBox::indicator:checked {{
    background-color: {CLR_RED};
    border: 1px solid {CLR_RED};
}}

QStatusBar {{
    background-color: {CLR_BG};
    color: {CLR_TEXT_DIM};
    font-family: "Courier", "Courier New", monospace;
    font-size: 11px;
    border-top: 1px solid {CLR_BORDER};
}}

QGroupBox {{
    border: 1px solid {CLR_BORDER};
    border-radius: 6px;
    margin-top: 14px;
    padding: 16px 12px 12px 12px;
    font-family: "Courier", "Courier New", monospace;
    font-weight: bold;
    color: {CLR_RED};
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 8px;
    color: {CLR_RED};
}}

QFrame#separator {{
    background-color: {CLR_BORDER};
    max-height: 1px;
}}
"""


# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  —  {ORG_NAME}")
        self.setMinimumSize(640, 480)
        self.resize(WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setStyleSheet(STYLESHEET)

        # Try to set the window icon
        icon_path = Path(__file__).parent / "icon.ico"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))

        self._worker: ConvertWorker | None = None
        self._build_ui()
        self._check_tools()

    # -----------------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Top section (scrollable) ──
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        scroll_area.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        scroll_area.setStyleSheet(
            f"QScrollBar:vertical {{"
            f"  background: {CLR_BG_LIGHT}; width: 10px; border: none;"
            f"}}"
            f"QScrollBar::handle:vertical {{"
            f"  background: {CLR_BORDER}; border-radius: 4px; min-height: 30px;"
            f"}}"
            f"QScrollBar::handle:vertical:hover {{ background: {CLR_RED}; }}"
            f"QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{"
            f"  height: 0px;"
            f"}}"
        )

        top_widget = QWidget()
        top_layout = QVBoxLayout(top_widget)
        top_layout.setContentsMargins(20, 16, 20, 12)
        top_layout.setSpacing(10)

        # ── Header ──
        hdr = QHBoxLayout()
        title_lbl = QLabel(APP_NAME)
        title_lbl.setObjectName("title")
        hdr.addWidget(title_lbl)
        hdr.addStretch()
        ver_lbl = QLabel(f"v{APP_VERSION}")
        ver_lbl.setObjectName("subtitle")
        hdr.addWidget(ver_lbl)
        top_layout.addLayout(hdr)

        sub_lbl = QLabel("Linux Package Format Converter  ·  DEB ↔ RPM ↔ Pacman")
        sub_lbl.setObjectName("subtitle")
        top_layout.addWidget(sub_lbl)

        sep = QFrame()
        sep.setObjectName("separator")
        sep.setFrameShape(QFrame.Shape.HLine)
        top_layout.addWidget(sep)

        # ── Source File ──
        src_group = QGroupBox("Source Package")
        src_lay = QGridLayout(src_group)
        src_lay.setSpacing(8)

        self.src_edit = QLineEdit()
        self.src_edit.setPlaceholderText("Select a .deb, .rpm, or .pkg.tar.zst file …")
        self.src_edit.setReadOnly(True)
        src_lay.addWidget(self.src_edit, 0, 0)

        src_btn = QPushButton("Browse")
        src_btn.setObjectName("browse")
        src_btn.clicked.connect(self._browse_source)
        src_lay.addWidget(src_btn, 0, 1)

        self.fmt_label = QLabel("Format: —")
        self.fmt_label.setObjectName("subtitle")
        src_lay.addWidget(self.fmt_label, 1, 0, 1, 2)

        top_layout.addWidget(src_group)

        # ── Target Format ──
        tgt_group = QGroupBox("Target Format")
        tgt_lay = QHBoxLayout(tgt_group)
        tgt_lay.setSpacing(12)

        self.tgt_combo = QComboBox()
        for fmt in PkgFormat:
            self.tgt_combo.addItem(fmt.label, fmt)
        tgt_lay.addWidget(QLabel("Convert to:"))
        tgt_lay.addWidget(self.tgt_combo)
        tgt_lay.addStretch()

        self.scripts_cb = QCheckBox("Convert install/remove scripts")
        self.scripts_cb.setChecked(True)
        self.scripts_cb.setToolTip(
            "Attempt to convert pre/post install/remove scripts.\n"
            "Use with caution — scripts may be distro-specific."
        )
        tgt_lay.addWidget(self.scripts_cb)

        top_layout.addWidget(tgt_group)

        # ── Output Directory ──
        out_group = QGroupBox("Output Directory")
        out_lay = QHBoxLayout(out_group)

        self.out_edit = QLineEdit()
        self.out_edit.setText(str(Path.home() / "Desktop"))
        self.out_edit.setReadOnly(True)
        out_lay.addWidget(self.out_edit)

        out_btn = QPushButton("Browse")
        out_btn.setObjectName("browse")
        out_btn.clicked.connect(self._browse_output)
        out_lay.addWidget(out_btn)

        top_layout.addWidget(out_group)

        # ── Convert Button ──
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        self.convert_btn = QPushButton("☠  CONVERT  ☠")
        self.convert_btn.setFixedHeight(44)
        self.convert_btn.setMinimumWidth(260)
        self.convert_btn.setStyleSheet(
            self.convert_btn.styleSheet() + "font-size: 16px;"
        )
        self.convert_btn.clicked.connect(self._start_conversion)
        btn_row.addWidget(self.convert_btn)

        btn_row.addStretch()
        top_layout.addLayout(btn_row)

        # ── Progress ──
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        top_layout.addWidget(self.progress_bar)

        scroll_area.setWidget(top_widget)
        main_layout.addWidget(scroll_area)

        # ── Log Output (below scroll area, always visible) ──
        log_container = QWidget()
        log_layout = QVBoxLayout(log_container)
        log_layout.setContentsMargins(20, 8, 20, 8)
        log_layout.setSpacing(6)

        log_header = QHBoxLayout()
        log_lbl = QLabel("Conversion Log")
        log_lbl.setObjectName("section")
        log_header.addWidget(log_lbl)
        log_header.addStretch()

        clear_btn = QPushButton("Clear")
        clear_btn.setObjectName("clear")
        clear_btn.clicked.connect(lambda: self.log_area.clear())
        log_header.addWidget(clear_btn)
        log_layout.addLayout(log_header)

        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setMinimumHeight(140)
        self.log_area.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        log_layout.addWidget(self.log_area)

        main_layout.addWidget(log_container, stretch=1)

        # ── Status Bar ──
        self.statusBar().showMessage(f"{ORG_NAME}  ·  {APP_NAME} v{APP_VERSION}")

    # -----------------------------------------------------------------
    def _check_tools(self):
        """Check for available backend tools and log the result."""
        tools = {
            "alien":    "DEB ↔ RPM conversions",
            "debtap":   "DEB → Pacman conversions",
            "dpkg-deb": "Building .deb packages",
            "rpm2cpio": "Extracting .rpm packages",
            "rpm":      "Reading RPM metadata",
            "tar":      "Archive operations",
            "ar":       "Extracting .deb archives",
        }
        self._log("Backend tool check:")
        all_good = True
        for tool, purpose in tools.items():
            avail = tool_available(tool)
            status = f'<span style="color:{CLR_GREEN}">✓ found</span>' if avail else f'<span style="color:{CLR_YELLOW}">✗ missing</span>'
            self._log(f"  {tool:12s} {status}  — {purpose}", html=True)
            if not avail and tool in ("alien", "tar"):
                all_good = False

        if not all_good:
            self._log("")
            self._log(
                f'<span style="color:{CLR_YELLOW}">⚠  Some tools are missing. '
                f'Install them for full conversion support.</span>',
                html=True,
            )
        self._log("─" * 60)

    # -----------------------------------------------------------------
    def _log(self, text: str, html: bool = False):
        if html:
            self.log_area.append(text)
        else:
            self.log_area.append(f'<span style="color:{CLR_TEXT}">{text}</span>')

    def _log_error(self, text: str):
        self.log_area.append(f'<span style="color:{CLR_ERROR}">✗ {text}</span>')

    def _log_success(self, text: str):
        self.log_area.append(f'<span style="color:{CLR_GREEN}">✓ {text}</span>')

    # -----------------------------------------------------------------
    def _browse_source(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Source Package",
            str(Path.home()),
            "Linux Packages (*.deb *.rpm *.pkg.tar.zst *.pkg.tar.xz *.pkg.tar.gz *.pkg.tar.bz2);;All Files (*)",
        )
        if path:
            self.src_edit.setText(path)
            fmt = detect_format(path)
            if fmt:
                self.fmt_label.setText(f"Format: {fmt.short}  ({fmt.label})")
                self.fmt_label.setStyleSheet(f"color: {CLR_GREEN};")
            else:
                self.fmt_label.setText("Format: Unknown")
                self.fmt_label.setStyleSheet(f"color: {CLR_ERROR};")

    def _browse_output(self):
        path = QFileDialog.getExistingDirectory(
            self, "Select Output Directory", self.out_edit.text()
        )
        if path:
            self.out_edit.setText(path)

    # -----------------------------------------------------------------
    def _start_conversion(self):
        src = self.src_edit.text().strip()
        if not src or not Path(src).is_file():
            QMessageBox.warning(self, APP_NAME, "Please select a valid source package file.")
            return

        src_fmt = detect_format(src)
        if src_fmt is None:
            QMessageBox.warning(
                self, APP_NAME,
                "Could not detect source format.\n"
                "Supported extensions: .deb, .rpm, .pkg.tar.zst, .pkg.tar.xz"
            )
            return

        tgt_fmt: PkgFormat = self.tgt_combo.currentData()
        if src_fmt == tgt_fmt:
            QMessageBox.information(
                self, APP_NAME,
                "Source and target formats are the same — nothing to convert."
            )
            return

        out_dir = self.out_edit.text().strip()
        if not out_dir or not Path(out_dir).is_dir():
            QMessageBox.warning(self, APP_NAME, "Please select a valid output directory.")
            return

        # Disable UI during conversion
        self.convert_btn.setEnabled(False)
        self.progress_bar.setValue(0)
        self._log("═" * 60)
        self._log(f"Starting conversion: {src_fmt.short} → {tgt_fmt.short}")
        self._log("═" * 60)

        self._worker = ConvertWorker(
            source_path=src,
            source_fmt=src_fmt,
            target_fmt=tgt_fmt,
            output_dir=out_dir,
            convert_scripts=self.scripts_cb.isChecked(),
        )
        self._worker.log_message.connect(self._log)
        self._worker.log_error.connect(self._log_error)
        self._worker.log_success.connect(self._log_success)
        self._worker.progress.connect(self.progress_bar.setValue)
        self._worker.finished_ok.connect(self._on_success)
        self._worker.finished_err.connect(self._on_error)
        self._worker.finished.connect(self._on_finished)
        self._worker.start()

    def _on_success(self, path: str):
        self._log("─" * 60)
        self._log_success(f"Conversion complete!")
        self._log(f"Output: {path}")
        self.statusBar().showMessage(f"Done — {Path(path).name}")

    def _on_error(self, msg: str):
        self._log("─" * 60)
        self._log_error(f"Conversion failed: {msg}")
        self.statusBar().showMessage("Conversion failed.")

    def _on_finished(self):
        self.convert_btn.setEnabled(True)


# =============================================================================
# Entry Point
# =============================================================================

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    # Icon
    icon_path = Path(__file__).parent / "icon.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # Splash
    splash = create_splash()
    if splash:
        splash.show()
        messages = [
            "Initializing …",
            "Checking backend tools …",
            "Loading converter engine …",
            "Ready to convert."
        ]
        for msg in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    # Main window
    window = MainWindow()
    window.show()

    if splash:
        splash.finish(window)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
